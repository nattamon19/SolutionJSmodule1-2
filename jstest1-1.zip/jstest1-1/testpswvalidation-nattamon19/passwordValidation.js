// 65130500035 Nattamon Thongkhamon
function isPasswordValid(password) {
  let [containLower, containUpper, containSp, containNumber] = [false,false,false,false];
  if(password === null || password === undefined ) return false;
  strArr = [...password];
  if(strArr.length < 8) return false;
  for (let i = 0; i < strArr.length; i++) {
    if (!containUpper) {
      if (strArr[i].charCodeAt(0) >= 65 && strArr[i].charCodeAt(0) <= 90) {
        containUpper = true;
      }
    }
    if (!containLower) {
      if (strArr[i].charCodeAt(0) >= 97 && strArr[i].charCodeAt(0) <= 102) {
        containLower = true;
      }
    }
    if (!containSp) {
      switch (strArr[i]) {
        case "@":
        case "#":
        case "$":
        case "%":
        case "^":
        case "&":
        case "*":
        case "!":
          containSp = true;
          break;
      }
    }
    if (!containNumber) {
      if (strArr[i].charCodeAt(0) >= 48 && strArr[i].charCodeAt(0) <= 57) {
        containNumber = true;
      }
    }
  }
  if(containLower && containUpper && containNumber && containSp) return true;
  else return false;
 }
console.log(isPasswordValid);
module.exports = isPasswordValid;
